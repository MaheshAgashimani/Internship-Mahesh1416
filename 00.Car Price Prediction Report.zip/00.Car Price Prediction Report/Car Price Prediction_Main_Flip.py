#!/usr/bin/env python
# coding: utf-8

# In[1]:


get_ipython().system('pip install selenium')


# In[2]:


import selenium
import pandas as pd
from selenium import webdriver
import warnings
warnings.filterwarnings('ignore')
from selenium.webdriver.common.by import By
import requests
import time
from selenium.common.exceptions import NoSuchElementException


# In[3]:


# Connect to webdriver
driver = webdriver.Chrome(r'C:\Users\COTMAC\Downloads\chromedriver_win32\chromedriver.exe')


# In[4]:


driver.get("https://www.cardekho.com/")
time.sleep(2)


# In[5]:


search=driver.find_element(By.XPATH,"/html/body/div[2]/div/header/div[2]/div/div/nav/ul/li[2]/span/span")
search.click()


# In[6]:


CarName=[]
BrandName=[]
Price=[]
RunningKM=[]
FuelType=[]
Type=[]


# In[31]:


# 5000 time we scroll down by 50000 in order to generate more Comments
for _ in range(5000):
    driver.execute_script("window.scrollBy(0,5000)")
    
time.sleep(5)


# In[34]:


CarName1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in CarName1[0:5001]:
        CarName.append(i.text.split('\n')[0])
        
time.sleep(500)


# In[35]:


len(CarName)


# In[36]:


BrandName1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in BrandName1[0:5001]:
        BrandName.append(i.text.split('\n')[1])
        
time.sleep(500)


# In[37]:


len(BrandName)


# In[38]:


Price1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in Price1[0:5001]:
        Price.append(i.text.split('\n')[2])
        
time.sleep(500)


# In[39]:


len(Price)


# In[40]:


RunningKM1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in RunningKM1[0:5001]:
        RunningKM.append(i.text.split('\n')[3])

time.sleep(500)


# In[41]:


len(RunningKM)


# In[42]:


FuelType1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in FuelType1[0:5001]:
        FuelType.append(i.text.split('\n')[4])
        
time.sleep(500)


# In[43]:


len(FuelType)


# In[44]:


Type1=driver.find_elements(By.XPATH,"//div[@class='gsc_col-xs-7  carsName']")
for i in Type1[0:5001]:
        Type.append(i.text.split('\n')[5])
        
time.sleep(500)


# In[45]:


len(Type)


# In[48]:


df = pd.DataFrame()
df['CarName'] = CarName[1:3458]
df['BrandName'] = BrandName[1:3458]
df['RunningKM'] = RunningKM[1:3459][1:3458]
df['FuelType'] = FuelType[1:3458]
df['Type'] = Type[1:3458]
df['Price'] = Price[1:3458]
df


# In[49]:


df


# In[50]:


df.head(2)


# In[51]:


df.tail(2)


# In[52]:


df.isnull().sum()


# In[53]:


df.shape


# In[54]:


df.dtypes


# In[55]:


#EDA Part Using countplot
import seaborn as sns


# In[56]:


ax=sns.countplot(x="CarName",data=df)
print(df["CarName"].value_counts())


# In[58]:


ax=sns.countplot(x="BrandName",data=df)
print(df["BrandName"].value_counts())


# In[59]:


ax=sns.countplot(x="RunningKM",data=df)
print(df["RunningKM"].value_counts())


# In[60]:


ax=sns.countplot(x="FuelType",data=df)
print(df["FuelType"].value_counts())


# In[61]:


ax=sns.countplot(x="Type",data=df)
print(df["Type"].value_counts())


# In[62]:


ax=sns.countplot(x="Price",data=df)
print(df["Price"].value_counts())


# In[63]:


#Encoding of data


# In[64]:


from sklearn.preprocessing import LabelEncoder
enc=LabelEncoder()


# In[65]:


for i in df.columns:
    if df[i].dtypes=='object':
        df[i]=enc.fit_transform(df[i].values.reshape(-1,1))


# In[66]:


df


# In[67]:


df.columns


# In[68]:


#Using Scatter Plot
sns.scatterplot(x='CarName',y='Price',data=df)


# In[69]:


sns.scatterplot(x='BrandName',y='Price',data=df)


# In[70]:


sns.scatterplot(x='RunningKM',y='Price',data=df)


# In[71]:


sns.scatterplot(x='FuelType',y='Price',data=df)


# In[72]:


sns.scatterplot(x='Type',y='Price',data=df)


# In[73]:


import matplotlib.pyplot as plt
sns.pairplot(df)
plt.savefig('pairplot.png')
plt.show()


# In[74]:


#Plotting the histogram for univarience analysis


# In[75]:


df.hist(figsize=(20,20),grid=True,layout=(8,8),bins=30)


# In[76]:


df.shape


# In[77]:


df.describe()


# In[78]:


#Correlation


# In[79]:


df.corr()


# In[80]:


df.corr()['Price'].sort_values()


# In[81]:


# Correlation using Heatmap
import matplotlib.pyplot as plt
plt.figure(figsize=(15,7))
sns.heatmap(df.corr(),annot=True,linewidth=0.5,linecolor='Black',fmt='.2f')


# In[82]:


df.plot(kind='density',subplots=True,layout=(6,11),sharex=False,legend=False,fontsize=1,figsize=(18,12))
plt.show()


# In[83]:


x=df.drop("Price",axis=1)
y=df["Price"]


# In[84]:


x


# In[85]:


y


# In[86]:


#No need to check skewness & outliers for Categorical data.Its a invalid operation


# In[87]:


import warnings
warnings.filterwarnings('ignore')


# In[88]:


from sklearn.feature_selection import mutual_info_classif


# In[89]:


mutual_info_classif(x,y)


# In[90]:


imp=pd.DataFrame(mutual_info_classif(x,y),index=x.columns)
imp


# In[91]:


imp.columns=['importance']
imp.sort_values(by='importance',ascending=False)


# In[92]:


from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.model_selection import train_test_split


# In[93]:


#splitting data into 80% training and 20% testing
X_train,X_test,y_train,y_test=train_test_split(x,y,test_size=0.2)


# In[94]:


from sklearn import metrics
import pickle
def predict(ml_model):
    model=ml_model.fit(X_train,y_train)
    print('Training score: {}'.format(model.score(X_train,y_train)))
    predictions=model.predict(X_test)
    print('Predictions are: {}'.format(predictions))
    print('\n')
    r2_score=metrics.r2_score(y_test,predictions)
    print('r2 score is {}'.format(r2_score))
    print('MAE:',metrics.mean_absolute_error(y_test,predictions))
    print('MSE:',metrics.mean_squared_error(y_test,predictions))
    print('RMSE:',np.sqrt(metrics.mean_absolute_error(y_test,predictions)))
    sns.distplot(y_test-predictions)


# In[97]:


from sklearn.ensemble import RandomForestRegressor
import numpy as np


# In[98]:


predict(RandomForestRegressor())


# In[99]:


predict(LinearRegression())


# In[100]:


predict(DecisionTreeRegressor())


# In[101]:


predict(KNeighborsRegressor())


# In[102]:


#As checked above Regressor RandomForestRegressor is the best model
from sklearn.ensemble import RandomForestRegressor


# In[103]:


n_estimators=[int(x) for x in np.linspace(start=100, stop=1200, num=6)]
max_depth=[int(x) for x in np.linspace(start=5, stop=30, num=4)]


# In[104]:


RF= RandomForestRegressor()


# In[105]:


from sklearn.model_selection import RandomizedSearchCV

parameters={
    'n_estimators': n_estimators,
    'max_features': ['auto','sqrt'],
    'max_depth':max_depth,
    'min_samples_split':[5,10,15,100]}


# In[107]:


RCV=RandomizedSearchCV(RandomForestRegressor(),parameters,cv=3, verbose=2, n_jobs=-1)
RCV.fit(X_train,y_train)
RCV.best_params_


# In[108]:


type(RCV)


# In[109]:


RCV.best_estimator_


# In[111]:


RCV_pred=RCV.best_estimator_.predict(X_test)


# In[112]:


from sklearn.metrics import r2_score
r2_score(y_test,RCV_pred)


# In[152]:


import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
plt.scatter(x=target_test,y=pred_test, color='y')
plt.plot(target_test,target_test,color='b')
plt.xlabel("Actual Price",fontsize=14)
plt.ylabel("Predicted Price",fontsize=14)
plt.title("Random Forest Regressor",fontsize=18)
plt.show()


# In[ ]:





# In[ ]:





# In[114]:


features=df.drop("Price",axis=1)
target=df["Price"]


# In[115]:


features


# In[116]:


target


# In[117]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.model_selection import train_test_split


# In[118]:


from sklearn.preprocessing import MinMaxScaler
mns=MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.tree import DecisionTreeRegressor
lr=LinearRegression()
rf=RandomForestRegressor()
kn=KNeighborsRegressor()
dt=DecisionTreeRegressor()
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split


# In[119]:


for i in range(0,100):
    features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=i)
    lr.fit(features_train,target_train)
    pred_train=lr.predict(features_train)
    pred_test=lr.predict(features_test)
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_train,pred_train)}")
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_test,pred_test)}")
    print("\n")


# In[120]:


for i in range(0,100):
    features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=i)
    rf.fit(features_train,target_train)
    pred_train=rf.predict(features_train)
    pred_test=rf.predict(features_test)
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_train,pred_train)}")
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_test,pred_test)}")
    print("\n")


# In[121]:


for i in range(0,100):
    features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=i)
    dt.fit(features_train,target_train)
    pred_train=dt.predict(features_train)
    pred_test=dt.predict(features_test)
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_train,pred_train)}")
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_test,pred_test)}")
    print("\n")


# In[122]:


for i in range(0,100):
    features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=i)
    kn.fit(features_train,target_train)
    pred_train=kn.predict(features_train)
    pred_test=kn.predict(features_test)
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_train,pred_train)}")
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_test,pred_test)}")
    print("\n")


# In[123]:


# As compare above RandomForestRegressor is best


# In[124]:


for i in range(0,100):
    features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=i)
    rf.fit(features_train,target_train)
    pred_train=rf.predict(features_train)
    pred_test=rf.predict(features_test)
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_train,pred_train)}")
    print(f"At Random state {i},the training accuracy is:- {r2_score(target_test,pred_test)}")
    print("\n")


# In[125]:


features_train,features_test,target_train,target_test=train_test_split(features,target,test_size=0.2,random_state=33)


# In[126]:


rf.fit(features_train,target_train)


# In[127]:


pred_test=rf.predict(features_test)


# In[128]:


print(r2_score(target_test,pred_test))


# In[129]:


#Cross Validation of Model


# In[130]:


Train_accuracy=r2_score(target_train,pred_train)
Test_accuracy=r2_score(target_test,pred_test)


# In[131]:


from sklearn.model_selection import cross_val_score
for j in range(2,20):
    cv_score=cross_val_score(rf,features,target,cv=j)
    cv_mean=cv_score.mean()
    print(f"At cross fold {j} the cv score is {cv_mean} and accuracy score for training is {Train_accuracy} and accuracy for the testing is {Test_accuracy}")
    print("\n")


# In[133]:


import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
plt.scatter(x=target_test,y=pred_test, color='y')
plt.plot(target_test,target_test,color='b')
plt.xlabel("Actual Price",fontsize=14)
plt.ylabel("Predicted Price",fontsize=14)
plt.title('RandomForestRegressor',fontsize=18)
plt.show()


# In[ ]:





# In[134]:


#Regularization


# In[135]:


from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
import warnings
warnings.filterwarnings('ignore')


# In[136]:


from sklearn.linear_model import Lasso


# In[137]:


parameters = {'alpha':[.0002,.002,.02,.2,2,20],'random_state':list(range(0,20))}
ls=Lasso()
clf=GridSearchCV(ls,parameters)
clf.fit(features_train,target_train)


# In[138]:


print(clf.best_params_)


# In[139]:


ls=Lasso(alpha=0.2,random_state=0)
ls.fit(features_train,target_train)
ls.score(features_train,target_train)
pred_ls=ls.predict(features_test)


# In[140]:


lss=r2_score(target_test,pred_ls)
lss


# In[141]:


cv_score=cross_val_score(ls,features,target,cv=3)
cv_mean=cv_score.mean()
cv_mean


# In[142]:


#Ensemble technoque


# In[143]:


from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor

parameters = {'criterion':['mse','mae'],'max_features':["auto","sqrt","log2"]}
rf=RandomForestRegressor()
clf=GridSearchCV(rf,parameters)
clf.fit(features_train,target_train)

print(clf.best_params_)


# In[145]:


rf=RandomForestRegressor(criterion="mae",max_features="sqrt")
rf.fit(features_train,target_train)
rf.score(features_train,target_train)
pred_decision=rf.predict(features_test)

rfs=r2_score(target_test,pred_decision)
print('R2 Score:',rfs*100)

rfscore=cross_val_score(rf,features,target,cv=3)
rfc=rfscore.mean()
print('cross val score:', rfc*100)


# In[ ]:


#difference between r2 score & cross_val_score is very less so random forest is best method


# In[146]:


import pickle
filename ='EV_CarPrice'
pickle.dump(rf,open(filename,'wb'))


# In[147]:


#Conclusion


# In[148]:


loaded_model=pickle.load(open('EV_CarPrice','rb'))
result=loaded_model.score(features_test,target_test)
print(result)


# In[149]:


conclusion = pd.DataFrame([loaded_model.predict(features_test)[:],pred_decision[:]],index=["predicted","origional"])


# In[150]:


conclusion


# In[ ]:





# In[ ]:





# In[ ]:




