#!/usr/bin/env python
# coding: utf-8

# In[18]:


import pandas as pd
import numpy as np


# In[19]:


pd.read_csv(r'D:/I/02.Flip Robo Assignments/01.Flip Robo Assignments/07.Project_Micro Credit Defaulter Project/Micro Credit Project/Data file.csv')


# In[20]:


df=pd.read_csv(r'D:/I/02.Flip Robo Assignments/01.Flip Robo Assignments/07.Project_Micro Credit Defaulter Project/Micro Credit Project/Data file.csv')


# In[21]:


df


# In[22]:


df.isnull().sum()


# In[6]:


df.dtypes


# In[7]:


#Object - msisdn, pcircle, pdate


# In[8]:


#Numeric - label, aon, daily_decr30, daily_decr90, rental30, rental90, last_rech_date_ma, last_rech_date_da


# In[9]:


#last_rech_amt_ma, cnt_ma_rech30, fr_ma_rech30, sumamnt_ma_rech30, medianamnt_ma_rech30, medianmarechprebal30


# In[10]:


#cnt_ma_rech90, fr_ma_rech90, sumamnt_ma_rech90, medianamnt_ma_rech90, medianmarechprebal90, cnt_da_rech30, fr_da_rech30


# In[11]:


#cnt_da_rech90, fr_da_rech90, cnt_loans30, amnt_loans30, maxamnt_loans30, medianamnt_loans30, cnt_loans90, amnt_loans90


# In[12]:


#maxamnt_loans90, maxamnt_loans90, payback30, payback90


# In[5]:


#EDA Part Using countplot for object
import seaborn as sns


# In[ ]:





# In[14]:


ax=sns.countplot(x="pcircle",data=df)
print(df["pcircle"].value_counts())


# In[15]:


ax=sns.countplot(x="pdate",data=df)
print(df["pdate"].value_counts())


# In[23]:


#Encoding of data


# In[24]:


from sklearn.preprocessing import OrdinalEncoder
enc=OrdinalEncoder()


# In[25]:


for i in df.columns:
    if df[i].dtypes=='object':
        df[i]=enc.fit_transform(df[i].values.reshape(-1,1)) 


# In[26]:


df


# In[27]:


df.columns


# In[21]:


#Numeric - label, aon, daily_decr30, daily_decr90, rental30, rental90, last_rech_date_ma, last_rech_date_da
#last_rech_amt_ma, cnt_ma_rech30, fr_ma_rech30, sumamnt_ma_rech30, medianamnt_ma_rech30, medianmarechprebal30
#cnt_ma_rech90, fr_ma_rech90, sumamnt_ma_rech90, medianamnt_ma_rech90, medianmarechprebal90, cnt_da_rech30, fr_da_rech30
#cnt_da_rech90, fr_da_rech90, cnt_loans30, amnt_loans30, maxamnt_loans30, medianamnt_loans30, cnt_loans90, amnt_loans90
#maxamnt_loans90, medianamnt_loans90, payback30, payback90


# In[22]:


#Using Scatter Plot
sns.scatterplot(x='aon',y='label',data=df)


# In[23]:


#Using Scatter Plot
sns.scatterplot(x='daily_decr30',y='label',data=df)


# In[24]:


#Using Scatter Plot
sns.scatterplot(x='daily_decr90',y='label',data=df)


# In[25]:


#Using Scatter Plot
sns.scatterplot(x='rental30',y='label',data=df)


# In[26]:


#Using Scatter Plot
sns.scatterplot(x='rental90',y='label',data=df)


# In[27]:


#Using Scatter Plot
sns.scatterplot(x='last_rech_date_ma',y='label',data=df)


# In[28]:


#Using Scatter Plot
sns.scatterplot(x='last_rech_date_da',y='label',data=df)


# In[29]:


#Using Scatter Plot
sns.scatterplot(x='last_rech_amt_ma',y='label',data=df)


# In[30]:


#Using Scatter Plot
sns.scatterplot(x='cnt_ma_rech30',y='label',data=df)


# In[31]:


#Using Scatter Plot
sns.scatterplot(x='fr_ma_rech30',y='label',data=df)


# In[32]:


#Using Scatter Plot
sns.scatterplot(x='sumamnt_ma_rech30',y='label',data=df)


# In[33]:


#Using Scatter Plot
sns.scatterplot(x='medianamnt_ma_rech30',y='label',data=df)


# In[34]:


#Using Scatter Plot
sns.scatterplot(x='medianmarechprebal30',y='label',data=df)


# In[ ]:


#cnt_ma_rech90, fr_ma_rech90, sumamnt_ma_rech90, medianamnt_ma_rech90, medianmarechprebal90, cnt_da_rech30, fr_da_rech30
#cnt_da_rech90, fr_da_rech90, cnt_loans30, amnt_loans30, maxamnt_loans30, medianamnt_loans30, cnt_loans90, amnt_loans90
#maxamnt_loans90, medianamnt_loans90, payback30, payback90


# In[ ]:





# In[9]:


#Using Scatter Plot
sns.scatterplot(x='cnt_ma_rech90',y='label',data=df)


# In[10]:


#Using Scatter Plot
sns.scatterplot(x='fr_ma_rech90',y='label',data=df)


# In[11]:


#Using Scatter Plot
sns.scatterplot(x='sumamnt_ma_rech90',y='label',data=df)


# In[12]:


#Using Scatter Plot
sns.scatterplot(x='medianamnt_ma_rech90',y='label',data=df)


# In[13]:


#Using Scatter Plot
sns.scatterplot(x='medianmarechprebal90',y='label',data=df)


# In[14]:


#Using Scatter Plot
sns.scatterplot(x='cnt_da_rech30',y='label',data=df)


# In[15]:


#Using Scatter Plot
sns.scatterplot(x='fr_da_rech30',y='label',data=df)


# In[16]:


#Using Scatter Plot
sns.scatterplot(x='cnt_da_rech90',y='label',data=df)


# In[17]:


#Using Scatter Plot
sns.scatterplot(x='fr_da_rech90',y='label',data=df)


# In[18]:


#Using Scatter Plot
sns.scatterplot(x='cnt_loans30',y='label',data=df)


# In[19]:


#Using Scatter Plot------------------------------------------
sns.scatterplot(x='amnt_loans30',y='label',data=df)


# In[20]:


#Using Scatter Plot
sns.scatterplot(x='maxamnt_loans30',y='label',data=df)


# In[21]:


#Using Scatter Plot
sns.scatterplot(x='medianamnt_loans30',y='label',data=df)


# In[22]:


#Using Scatter Plot
sns.scatterplot(x='cnt_loans90',y='label',data=df)


# In[23]:


#Using Scatter Plot
sns.scatterplot(x='amnt_loans90',y='label',data=df)


# In[24]:


#Using Scatter Plot
sns.scatterplot(x='maxamnt_loans90',y='label',data=df)


# In[25]:


#Using Scatter Plot
sns.scatterplot(x='medianamnt_loans90',y='label',data=df)


# In[26]:


#Using Scatter Plot
sns.scatterplot(x='payback30',y='label',data=df)


# In[27]:


#Using Scatter Plot
sns.scatterplot(x='payback90',y='label',data=df)


# In[11]:


#Plotting the histogram for univarience analysis
df.hist(figsize=(20,20),grid=True,layout=(8,8),bins=30)


# In[12]:


df.shape


# In[13]:


df.describe()


# In[14]:


#Correlation


# In[15]:


df.corr()


# In[16]:


df.corr()['label'].sort_values()


# In[17]:


# Correlation using Heatmap
import matplotlib.pyplot as plt
plt.figure(figsize=(15,7))
sns.heatmap(df.corr(),annot=True,linewidth=0.5,linecolor='Black',fmt='.2f')


# In[28]:


df=df.drop("Unnamed: 0",axis=1)


# In[29]:


x=df.drop("label",axis=1)
y=df["label"]


# In[30]:


x


# In[31]:


y


# In[24]:


# There is no multicolinearity Checking Skewness
df.skew()


# In[25]:


df.skew().sort_values(ascending=False)


# In[32]:


#Removing skewness using power transform method


# In[33]:


import warnings
warnings.filterwarnings('ignore')


# In[34]:


from sklearn.preprocessing import power_transform
df_new=power_transform(df)


# In[35]:


df_new


# In[30]:


#Checking Skewness


# In[31]:


pd.DataFrame(df_new,columns=df.columns).skew().sort_values(ascending=False)


# In[32]:


# To checking Outliers


# In[33]:


df.columns


# In[34]:


collist = x.columns.values
ncol = 30
nrows = 14
plt.figure(figsize=(ncol,3*ncol))
for i in range(0,len(collist)):
    plt.subplot(nrows,ncol,i+1)
    sns.boxplot(data=x[collist[i]],color='green',orient='v')
    plt.tight_layout()


# In[35]:


# to checking outliers using boxplot


# In[40]:


df.plot(kind='box',subplots=True,layout=(10,10),figsize=(36,30))


# In[36]:


# Removing Outliers Using Z score
from scipy.stats import zscore
import numpy as np
z=np.abs(zscore(df))
threshold = 3
np.where(z>3)


# In[42]:


df_new_z=df[(z<3).all(axis=1)]
df_new_z


# In[43]:


df_new_z.shape


# In[44]:


df.shape


# In[ ]:





# In[ ]:





# In[ ]:





# In[37]:


from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix,classification_report
from sklearn.model_selection import train_test_split


# In[38]:


#Best Random State
maxAccu=0
maxRS=0

for i in range(1,100):
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.20,random_state=i)
    LR=LogisticRegression()
    LR.fit(x_train,y_train)
    predrf=LR.predict(x_test)
    acc=accuracy_score(y_test,predrf)
    print('accuracy',acc,'random_state',i)
    
    if acc>maxAccu:
        maxAccu=acc
        maxRS=i
        print('max_accuracy',maxAccu,'max_random_state',i)


# In[39]:


print("Best Accuracy is ",maxAccu,"on Random_State",maxRS)


# In[40]:


x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.20,random_state=81)


# In[49]:


x_train.shape


# In[50]:


x_test.shape


# In[51]:


y_train.shape


# In[52]:


y_test.shape


# In[53]:


#Using Logistic Regression


# In[54]:


from sklearn.linear_model import LogisticRegression
LR=LogisticRegression()
LR.fit(x_train,y_train)
predlr=LR.predict(x_test)
print("Accuracy",accuracy_score(y_test,predlr)*100)
print(confusion_matrix(y_test,predlr))
print(classification_report(y_test,predlr))


# In[55]:


#Using Decision Tree


# In[56]:


from sklearn.tree import DecisionTreeClassifier

dt=DecisionTreeClassifier()
dt.fit(x_train,y_train)
preddt=dt.predict(x_test)
print("Accuracy",accuracy_score(y_test,predlr)*100)
print(confusion_matrix(y_test,preddt))
print(classification_report(y_test,preddt))


# In[41]:


#Using RandomForest
from sklearn.ensemble import RandomForestClassifier

rf=RandomForestClassifier()
rf.fit(x_train,y_train)
predrf=rf.predict(x_test)
print("Accuracy",accuracy_score(y_test,predrf)*100)
print(confusion_matrix(y_test,predrf))
print(classification_report(y_test,predrf))


# In[58]:


#Using SVC
from sklearn.svm import SVC

svc=SVC()
svc.fit(x_train,y_train)
predsvc=svc.predict(x_test)

print("Accuracy",accuracy_score(y_test,predsvc)*100)
print(confusion_matrix(y_test,predsvc))
print(classification_report(y_test,predsvc))


# In[59]:


#Using ExtraTreesClassifier
from sklearn.ensemble import ExtraTreesClassifier

etc=ExtraTreesClassifier()
etc.fit(x_train,y_train)
predetc=etc.predict(x_test)

print("Accuracy",accuracy_score(y_test,predetc)*100)
print(confusion_matrix(y_test,predetc))
print(classification_report(y_test,predetc))


# In[60]:


#Using KNN Classifier
from sklearn.neighbors import KNeighborsClassifier

knn=KNeighborsClassifier()
knn.fit(x_train,y_train)
predknn=knn.predict(x_test)

print("Accuracy",accuracy_score(y_test,predknn)*100)
print(confusion_matrix(y_test,predknn))
print(classification_report(y_test,predknn))


# In[62]:


#As checked above Random forest classifier accuracy is good


# In[63]:


#Cross Validation
from sklearn.model_selection import cross_val_score


# In[64]:


scr=cross_val_score(LR,x,y,cv=2)
print("Cross validation score for LOgistic Regression",scr.mean())


# In[65]:


scr


# In[66]:


scr19=cross_val_score(rf,x,y,cv=19)
print("Cross validation score for Random Forest",scr19.mean())


# In[67]:


scr19


# In[68]:


scr30=cross_val_score(rf,x,y,cv=18)
print("Cross validation score for Random Forest",scr30.mean())


# In[69]:


dt19=cross_val_score(dt,x,y,cv=19)
print("Cross validation score for Decision Tree",dt19.mean())


# In[70]:


dt19


# In[71]:


etc19=cross_val_score(etc,x,y,cv=19)
print("Cross validation score for Etraa Tree",etc19.mean())


# In[72]:


#Random Forest is the best classifier so using Random Forest


# In[73]:


#Hyper parameter tunning


# In[42]:


from sklearn.model_selection import GridSearchCV

parameters={'max_features':['auto','sqrt','log2'],
           'max_depth':[2,3,4,5,6],
           'criterion':['gini','entrophy']}


# In[43]:


GCV=GridSearchCV(RandomForestClassifier(),parameters,cv=2,scoring="accuracy")
GCV.fit(x_train,y_train)
GCV.best_params_


# In[76]:


type(GCV)


# In[77]:


GCV.best_estimator_


# In[78]:


GCV_pred=GCV.best_estimator_.predict(x_test)
accuracy_score(y_test,GCV_pred)


# In[79]:


#ROC AUC plot
import matplotlib.pyplot as plt
plt.figure(figsize=(8,6))
plt.scatter(x=y_test,y=predrf, color='y')
plt.plot(y_test,y_test,color='b')
plt.xlabel("Actual Rain Tomorrow",fontsize=14)
plt.ylabel("Predicted Rain Tomorrow",fontsize=14)
plt.title('Random Forest Regression',fontsize=18)
plt.show()


# In[80]:


#Regularization


# In[44]:


from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
import warnings
warnings.filterwarnings('ignore')


# In[45]:


from sklearn.linear_model import Lasso


# In[46]:


parameters = {'alpha':[.0002,.002,.02,.2,2,20],'random_state':list(range(0,20))}
ls=Lasso()
clf=GridSearchCV(ls,parameters)
clf.fit(x_train,y_train)


# In[47]:


print(clf.best_params_)


# In[48]:


ls=Lasso(alpha=0.0002,random_state=0)
ls.fit(x_train,y_train)
ls.score(x_train,y_train)
pred_ls=ls.predict(x_test)


# In[49]:


from sklearn.metrics import r2_score
lss=r2_score(y_test,pred_ls)
lss


# In[50]:


cv_score=cross_val_score(ls,x_train,y_train,cv=3)
cv_mean=cv_score.mean()
cv_mean


# In[ ]:


#Ensemble technoque
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor

parameters = {'criterion':['mse','mae'],'max_features':["auto","sqrt","log2"]}
rf=RandomForestRegressor()
clf=GridSearchCV(rf,parameters)
clf.fit(x_train,y_train)

print(clf.best_params_)


# In[ ]:


rf=RandomForestRegressor(criterion="mse",max_features="log2")
rf.fit(x_train,y_train)
rf.score(x_train,y_train)
pred_decision=rf.predict(x_test)

rfs=r2_score(y_test,pred_decision)
print('R2 Score:',rfs*100)

rfscore=cross_val_score(rf,x_train,y_train,cv=3)
rfc=rfscore.mean()
print('cross val score:', rfc*100)


# In[ ]:


#difference between r2 score & cross_val_score is very less so random forest is best method


# In[ ]:


import pickle
filename ='Micro_Prediction'
pickle.dump(rf,open(filename,'wb'))


# In[ ]:


#Conclusion


# In[ ]:


loaded_model=pickle.load(open('Micro_Prediction','rb'))
result=loaded_model.score(x_test,y_test)
print(result)


# In[ ]:


conclusion = pd.DataFrame([loaded_model.predict(x_test)[:],pred_decision[:]],index=["predicted","origional"])


# In[ ]:


conclusion


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




